document.addEventListener('DOMContentLoaded', function () {
    fetchCryptoData();
});

function fetchCryptoData() {
    fetch('https://api.coinlore.net/api/tickers/')
        .then(response => response.json())
        .then(data => {
            const cryptoList = document.getElementById('crypto-list');
            cryptoList.innerHTML = '';
            data.data.forEach(crypto => {
                const cryptoItem = document.createElement('div');
                cryptoItem.classList.add('crypto-item');
                cryptoItem.innerHTML = `
                    <div class="crypto-name">${crypto.name} (${crypto.symbol})</div>
                    <div>Price: <span class="crypto-price">$${crypto.price_usd}</span></div>
                    <div>Change (24h): <span class="crypto-change">${crypto.percent_change_24h}%</span></div>
                `;
                cryptoList.appendChild(cryptoItem);
            });
        })
        .catch(error => console.error('Error fetching crypto data:', error));
}
