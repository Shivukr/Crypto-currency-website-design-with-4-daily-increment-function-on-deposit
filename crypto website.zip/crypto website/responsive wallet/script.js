let walletBalance = 0;
const balanceDisplay = document.getElementById('walletBalance');
const transactionDetails = document.getElementById('transactionDetails');

function updateBalanceDisplay() {
    balanceDisplay.textContent = `$${walletBalance.toFixed(2)}`;
}

document.getElementById('addMoneyForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const amountToAdd = parseFloat(document.getElementById('amountToAdd').value);
    if (!isNaN(amountToAdd) && amountToAdd > 0) {
        walletBalance += amountToAdd;
        updateBalanceDisplay();
        document.getElementById('amountToAdd').value = ''; // Clear input field
    }
});

document.getElementById('withdrawMoneyForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const amountToWithdraw = parseFloat(document.getElementById('amountToWithdraw').value);
    if (!isNaN(amountToWithdraw) && amountToWithdraw > 0 && amountToWithdraw <= walletBalance) {
        const taxAmount = amountToWithdraw * 0.20; // Calculate tax
        const remainingBalance = walletBalance - (amountToWithdraw + taxAmount); // Calculate remaining balance after withdrawal and tax
        if (remainingBalance >= 0) { // Check if the remaining balance is not negative
            walletBalance -= (amountToWithdraw + taxAmount); // Deduct withdrawn amount and tax
            updateBalanceDisplay();
            transactionDetails.textContent = `Withdrawn: $${amountToWithdraw.toFixed(2)}, Tax Charged: $${taxAmount.toFixed(2)}`;
        } else {
            alert("Insufficient funds in your wallet after tax deduction.");
        }
        document.getElementById('amountToWithdraw').value = ''; // Clear input field
    }
});

function increaseBalance() {
    walletBalance *= 1.04; // Increase balance by 4% every minute (1.04^(1/60))
    updateBalanceDisplay();
}

setInterval(increaseBalance, 60000); // 60000 milliseconds = 1 minute

updateBalanceDisplay();
