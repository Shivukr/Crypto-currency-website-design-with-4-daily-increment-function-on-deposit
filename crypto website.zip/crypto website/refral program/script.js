document.getElementById('referralForm').addEventListener('submit', function(event) {
    event.preventDefault();
    var friendName = document.getElementById('friendName').value;
    var friendEmail = document.getElementById('friendEmail').value;
    // Here you can perform any action you want with the referral data, like sending it to a server
    // For now, let's just display the referral status
    displayReferralStatus('Referral sent to ' + friendName + ' (' + friendEmail + ')');
});

function displayReferralStatus(message) {
    var referralStatus = document.getElementById('referralStatus');
    referralStatus.style.display = 'block';
    referralStatus.textContent = message;
}
