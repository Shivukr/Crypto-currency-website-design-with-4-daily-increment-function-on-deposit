// Function to handle form submission
document.getElementById('transactionForm').addEventListener('submit', function(event) {
    event.preventDefault();
    var recipient = document.getElementById('recipient').value;
    var amount = parseFloat(document.getElementById('amount').value);
    
    // Assume successful transaction
    recordTransaction(recipient, amount);
    alert('Transaction Successful!');
});

// Function to record transaction and update transaction history
function recordTransaction(recipient, amount) {
    var transactionHistory = document.getElementById('transactionHistory');
    var transactionItem = document.createElement('li');
    transactionItem.classList.add('transaction');
    transactionItem.textContent = 'Sent $' + amount.toFixed(2) + ' to ' + recipient + ' - ' + new Date().toLocaleString();
    transactionHistory.insertBefore(transactionItem, transactionHistory.firstChild);
}
