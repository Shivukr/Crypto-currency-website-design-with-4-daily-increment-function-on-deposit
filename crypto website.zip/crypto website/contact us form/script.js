// Function to handle form submission
document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var message = document.getElementById('message').value;
    
    // Assuming successful submission
    displayPopup('Thank you, ' + name + '! Your message has been sent.');
    clearForm();
});

// Function to display popup
function displayPopup(message) {
    var popup = document.getElementById('popup');
    var popupMessage = document.getElementById('popupMessage');
    popupMessage.textContent = message;
    popup.style.display = 'block';
}

// Function to clear form after submission
function clearForm() {
    document.getElementById('name').value = '';
    document.getElementById('email').value = '';
    document.getElementById('message').value = '';
}

// Function to close popup
function closePopup() {
    var popup = document.getElementById('popup');
    popup.style.display = 'none';
}
