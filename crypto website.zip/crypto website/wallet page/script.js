// Simulated balance data
var balance = 1000; // Initial balance

// Display initial balance
displayBalance();

// Function to display balance
function displayBalance() {
    var balanceElement = document.getElementById('balance');
    balanceElement.textContent = 'Balance: $' + balance.toFixed(2);
}

// Function to handle deposit form submission
document.getElementById('depositForm').addEventListener('submit', function(event) {
    event.preventDefault();
    var depositAmount = parseFloat(document.getElementById('depositAmount').value);
    if (depositAmount) {
        balance += depositAmount; // Increase balance
        displayBalance();
        alert('Successfully deposited $' + depositAmount.toFixed(2));
        // Here you can perform additional actions, such as updating the user's balance on the server
    } else {
        alert('Please enter a valid deposit amount!');
    }
});

// Function to handle withdrawal form submission
document.getElementById('withdrawalForm').addEventListener('submit', function(event) {
    event.preventDefault();
    var withdrawalAmount = parseFloat(document.getElementById('withdrawalAmount').value);
    if (withdrawalAmount) {
        if (withdrawalAmount <= balance) {
            balance -= withdrawalAmount; // Decrease balance
            displayBalance();
            alert('Successfully withdrawn $' + withdrawalAmount.toFixed(2));
            // Here you can perform additional actions, such as updating the user's balance on the server
        } else {
            alert('Insufficient funds!');
        }
    } else {
        alert('Please enter a valid withdrawal amount!');
    }
});
