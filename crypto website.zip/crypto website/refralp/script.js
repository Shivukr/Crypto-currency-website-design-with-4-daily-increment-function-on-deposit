document.addEventListener("DOMContentLoaded", function() {
    const copyButton = document.getElementById("copyButton");
    const referralLink = document.getElementById("referralLink");
  
    copyButton.addEventListener("click", function() {
      referralLink.select();
      document.execCommand("copy");
      alert("Copied to clipboard!");
    });
  });
  