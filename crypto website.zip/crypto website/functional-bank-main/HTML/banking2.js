document.addEventListener('DOMContentLoaded', function() {
    const balanceDisplay = document.getElementById('balance');
    const depositAmountInput = document.getElementById('depositAmount');
    const depositBtn = document.getElementById('depositBtn');
  
    let walletBalance = 0;
  
    // Function to update balance display
    function updateBalanceDisplay() {
      balanceDisplay.textContent = `Balance: $${walletBalance.toFixed(2)}`;
    }
  
    // Function to deposit funds into the wallet
    function depositFunds() {
      const amount = parseFloat(depositAmountInput.value);
      if (!isNaN(amount) && amount > 0) {
        walletBalance += amount;
        updateBalanceDisplay();
        depositAmountInput.value = ''; // Clear input field after deposit
      } else {
        alert('Please enter a valid deposit amount.');
      }
    }
  
    // Function to increment balance by 4% every minute
    function incrementBalance() {
      const incrementAmount = walletBalance * 0.04;
      walletBalance += incrementAmount;
      updateBalanceDisplay();
    }
  
    // Timer to increment balance every minute
    setInterval(incrementBalance, 60 * 1000); // 1 minute
  
    // Event listener for deposit button click
    depositBtn.addEventListener('click', depositFunds);
  
    // Initial update of balance display
    updateBalanceDisplay();
  });
  