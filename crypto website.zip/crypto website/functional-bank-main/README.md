# functional-bank
# Project 06 || Fuctional Bank
## It is functional bank deposit and withdraw projet by Javascript, html, css. I used some common function to do not repeat the same code again.
## JavaScript
## html
## css
